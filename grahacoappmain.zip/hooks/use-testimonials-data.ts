"use client"

import { useState, useEffect } from "react"

export interface Testimonial {
  name: string
  role: string
  content: string
  rating: number
}

export function useTestimonialsData() {
  const testimonials: Testimonial[] = [
    {
      name: "Rina & Adi",
      role: "Klien Rumah Tinggal",
      content:
        "Awalnya kami takut biaya membengkak dan proyek molor, tapi bersama Grahaco semua berjalan sesuai rencana. Progresnya jelas, biayanya transparan, dan hasil rumah kami jauh melebihi ekspektasi. Terima kasih Grahaco sudah mewujudkan rumah impian pertama kami!",
      rating: 5,
    },
    {
      name: "Bapak Hendra",
      role: "Renovasi Hunian",
      content:
        "Saya melakukan renovasi rumah lama agar lebih nyaman ditinggali. Tim Grahaco sangat profesional, memberi banyak masukan soal desain dan material, dan hasilnya rumah jadi lebih modern serta hemat energi. Prosesnya juga tanpa ribet karena semuanya di-handle oleh tim.",
      rating: 5,
    },
    {
      name: "Clara",
      role: "Klien Desain Interior",
      content:
        "Yang saya suka dari Grahaco adalah detailnya. Dari 3D render, pilihan material, sampai laporan mingguan, semua jelas dan transparan. Saya bisa tetap tenang walau sibuk kerja, karena progress selalu terpantau. Interior rumah pun sesuai dengan gaya yang saya mau.",
      rating: 5,
    },
  ]

  return { testimonials }
}

export function useTestimonialCarousel(testimonials: Testimonial[]) {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isHovered, setIsHovered] = useState(false)
  const [isAutoPlaying, setIsAutoPlaying] = useState(true)

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => {
      const nextIndex = prevIndex + 1
      // Reset to 0 when reaching the end to create infinite loop
      if (nextIndex >= testimonials.length - 2) {
        return 0
      }
      return nextIndex
    })
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => {
      if (prevIndex === 0) {
        return testimonials.length - 3 // Go to last set of 3 cards
      }
      return prevIndex - 1
    })
  }

  useEffect(() => {
    if (isAutoPlaying && !isHovered) {
      const interval = setInterval(() => {
        nextSlide()
      }, 3000) // 3 seconds autoplay

      return () => clearInterval(interval)
    }
  }, [isHovered, isAutoPlaying, testimonials.length])

  const handleMouseEnter = () => {
    setIsHovered(true)
  }

  const handleMouseLeave = () => {
    setIsHovered(false)
  }

  return {
    currentIndex,
    setCurrentIndex,
    isHovered,
    setIsHovered,
    nextSlide,
    prevSlide,
    handleMouseEnter,
    handleMouseLeave,
    isAutoPlaying,
    setIsAutoPlaying,
  }
}
